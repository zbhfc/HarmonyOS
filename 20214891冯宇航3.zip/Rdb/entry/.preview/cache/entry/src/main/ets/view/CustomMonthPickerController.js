export class CustomMonthPickerDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__yearValue = new SynchedPropertySimpleTwoWayPU(params.yearValue, this, "yearValue");
        this.__monthValue = new SynchedPropertySimpleTwoWayPU(params.monthValue, this, "monthValue");
        this.__searchValue = new SynchedPropertySimpleTwoWayPU(params.searchValue, this, "searchValue");
        this.controller = undefined;
        this.cancel = undefined;
        this.confirm = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.cancel !== undefined) {
            this.cancel = params.cancel;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__yearValue.purgeDependencyOnElmtId(rmElmtId);
        this.__monthValue.purgeDependencyOnElmtId(rmElmtId);
        this.__searchValue.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__yearValue.aboutToBeDeleted();
        this.__monthValue.aboutToBeDeleted();
        this.__searchValue.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get yearValue() {
        return this.__yearValue.get();
    }
    set yearValue(newValue) {
        this.__yearValue.set(newValue);
    }
    get monthValue() {
        return this.__monthValue.get();
    }
    set monthValue(newValue) {
        this.__monthValue.set(newValue);
    }
    get searchValue() {
        return this.__searchValue.get();
    }
    set searchValue(newValue) {
        this.__searchValue.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/CustomMonthPickerController.ets(10:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('请输入待查询年月');
            Text.debugLine("view/CustomMonthPickerController.ets(11:7)");
            Text.fontSize(20);
            Text.margin({ top: 10, bottom: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/CustomMonthPickerController.ets(12:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '', text: this.yearValue });
            TextInput.debugLine("view/CustomMonthPickerController.ets(13:9)");
            TextInput.height(40);
            TextInput.width(100);
            TextInput.onChange((value) => {
                this.yearValue = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('年');
            Text.debugLine("view/CustomMonthPickerController.ets(17:9)");
            Text.fontSize(20);
            Text.margin({ top: 10, bottom: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '', text: this.monthValue });
            TextInput.debugLine("view/CustomMonthPickerController.ets(18:9)");
            TextInput.height(40);
            TextInput.width(100);
            TextInput.onChange((value) => {
                this.monthValue = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('月');
            Text.debugLine("view/CustomMonthPickerController.ets(22:9)");
            Text.fontSize(20);
            Text.margin({ top: 10, bottom: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ justifyContent: FlexAlign.SpaceAround });
            Flex.debugLine("view/CustomMonthPickerController.ets(24:7)");
            Flex.margin({ bottom: 10 });
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('取消');
            Button.debugLine("view/CustomMonthPickerController.ets(25:9)");
            Button.onClick(() => {
                this.controller.close();
                this.cancel;
            });
            Button.backgroundColor(0xffffff);
            Button.fontColor(Color.Red);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("view/CustomMonthPickerController.ets(30:9)");
            Divider.vertical(true);
            Divider.height(22);
            Divider.color('#ff647a91');
            Divider.opacity(0.6);
            Divider.margin({ left: 8, right: 8 });
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('确认');
            Button.debugLine("view/CustomMonthPickerController.ets(31:9)");
            Button.onClick(() => {
                this.searchValue = this.yearValue + '-' + this.monthValue;
                this.controller.close();
                this.confirm(this.yearValue, this.monthValue, this.searchValue);
            });
            Button.backgroundColor(0xffffff);
            Button.fontColor(Color.Black);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Flex.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=CustomMonthPickerController.js.map