const YEAR = '年';
const Month = '月';
const Day = '日';
export function padTo2Digits(num) {
    return num.toString().padStart(2, '0');
}
export function dateTostr(date) {
    return date.toDateString();
}
export function dateFormat(date) {
    return date.getFullYear() + YEAR + padTo2Digits(date.getMonth() - 1) + Month + padTo2Digits(date.getDate()) + Day;
}
export function DateFormat(timestamp) {
    let tempDate = new Date(timestamp);
    return dateFormat(tempDate);
}
//# sourceMappingURL=Utils.js.map