export default class CashText extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__amount = new SynchedPropertySimpleOneWayPU(params.amount, this, "amount");
        this.fontSize = '12vp';
        this.fontWeight = 500;
        this.fontFamily = 'HarmonyHeiTi-Bold';
        this.fontColor = '#FFFFFF';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.fontSize !== undefined) {
            this.fontSize = params.fontSize;
        }
        if (params.fontWeight !== undefined) {
            this.fontWeight = params.fontWeight;
        }
        if (params.fontFamily !== undefined) {
            this.fontFamily = params.fontFamily;
        }
        if (params.fontColor !== undefined) {
            this.fontColor = params.fontColor;
        }
    }
    updateStateVars(params) {
        this.__amount.reset(params.amount);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__amount.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__amount.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get amount() {
        return this.__amount.get();
    }
    set amount(newValue) {
        this.__amount.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.amount);
            Text.debugLine("view/CashTextComponent.ets(9:5)");
            Text.fontSize(this.fontSize);
            Text.fontWeight(this.fontWeight);
            Text.fontColor(this.fontColor);
            Text.fontFamily(this.fontFamily);
            Text.baselineOffset(-50);
            Text.textAlign(TextAlign.Start);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=CashTextComponent.js.map