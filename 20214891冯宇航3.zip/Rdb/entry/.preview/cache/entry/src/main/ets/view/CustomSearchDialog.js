import CommonConstants from '@bundle:com.example.rdb/entry/ets/common/constants/CommonConstants';
export class CustomSearchDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__submitValue = new SynchedPropertySimpleTwoWayPU(params.submitValue, this, "submitValue");
        this.searchController = new SearchController();
        this.controller = undefined;
        this.cancel = undefined;
        this.confirm = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.searchController !== undefined) {
            this.searchController = params.searchController;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.cancel !== undefined) {
            this.cancel = params.cancel;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__submitValue.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__submitValue.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get submitValue() {
        return this.__submitValue.get();
    }
    set submitValue(newValue) {
        this.__submitValue.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/CustomSearchDialog.ets(10:5)");
            Column.width(CommonConstants.FULL_WIDTH);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Search.create({
                value: '',
                placeholder: '请输入查询内容',
                controller: this.searchController
            });
            Search.debugLine("view/CustomSearchDialog.ets(11:7)");
            Search.searchButton('搜索');
            Search.width('80%');
            Search.height(40);
            Search.backgroundColor('#F5F5F5');
            Search.placeholderColor(Color.Grey);
            Search.placeholderFont({ size: 14, weight: 400 });
            Search.textFont({ size: 14, weight: 400 });
            Search.onSubmit((value) => {
                this.submitValue = value;
                this.controller.close();
                this.confirm(this.submitValue);
            });
            Search.margin(20);
            if (!isInitialRender) {
                Search.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Search.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=CustomSearchDialog.js.map