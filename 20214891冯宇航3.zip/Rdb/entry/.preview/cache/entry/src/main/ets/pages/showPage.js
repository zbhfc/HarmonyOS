import router from '@ohos:router';
import { CustomPieChart, PicChartElement } from '@bundle:com.example.rdb/entry/ets/view/chart';
class ShowPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        var _a, _b;
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.picChartElements = [];
        this.picChartElements2 = [];
        this.accounts = (_a = router.getParams()) === null || _a === void 0 ? void 0 : _a['data'];
        this.col = ['#ff9421', '#ffd100', '#4cd041', '#4cd0ee', '#999999', '#ED1C24', '#00CCCC', '#4169E1', '#EED202', '#FF6700', '#FF6FFF'];
        this.text = (_b = router.getParams()) === null || _b === void 0 ? void 0 : _b['title'];
        this.c1 = false;
        this.c2 = false;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.picChartElements !== undefined) {
            this.picChartElements = params.picChartElements;
        }
        if (params.picChartElements2 !== undefined) {
            this.picChartElements2 = params.picChartElements2;
        }
        if (params.accounts !== undefined) {
            this.accounts = params.accounts;
        }
        if (params.col !== undefined) {
            this.col = params.col;
        }
        if (params.text !== undefined) {
            this.text = params.text;
        }
        if (params.c1 !== undefined) {
            this.c1 = params.c1;
        }
        if (params.c2 !== undefined) {
            this.c2 = params.c2;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    aboutToAppear() {
        for (let i = 0; i < this.accounts.length; ++i) {
            if (this.accounts[i].accountType == 0) {
                this.c1 = true;
                for (let j = 0; j < this.picChartElements.length; ++j) {
                    if (this.picChartElements[j].element == this.accounts[i].typeText) {
                        this.c1 = false;
                    }
                }
                if (this.c1)
                    this.picChartElements.push(new PicChartElement(this.accounts[i].typeText, this.accounts[i].amount, this.col[this.picChartElements.length]));
                else {
                    for (let j = 0; j < this.picChartElements.length; ++j) {
                        if (this.picChartElements[j].element == this.accounts[i].typeText) {
                            this.picChartElements[j].quantity += this.accounts[i].amount;
                        }
                    }
                }
            }
            else {
                this.c2 = true;
                for (let j = 0; j < this.picChartElements2.length; ++j)
                    if (this.picChartElements2[j].element == this.accounts[i].typeText)
                        this.c2 = false;
                if (this.c2)
                    this.picChartElements2.push(new PicChartElement(this.accounts[i].typeText, this.accounts[i].amount, this.col[this.picChartElements.length]));
                else
                    for (let j = 0; j < this.picChartElements2.length; ++j)
                        if (this.picChartElements2[j].element == this.accounts[i].typeText)
                            this.picChartElements2[j].quantity += this.accounts[i].amount;
            }
        }
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/showPage.ets(54:7)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.text);
            Text.debugLine("pages/showPage.ets(55:9)");
            Text.height("55vp");
            Text.fontSize('50vp');
            Text.margin({ left: '24vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            __Common__.create();
            __Common__.position({ x: '3%', y: '10%' });
            if (!isInitialRender) {
                __Common__.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new CustomPieChart(this, { picChartElements: this.picChartElements }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        __Common__.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('支出');
            Text.debugLine("pages/showPage.ets(61:9)");
            Text.height("35vp");
            Text.fontSize('30vp');
            Text.margin({ left: '24vp' });
            Text.position({ x: '45%', y: '40%' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            __Common__.create();
            __Common__.position({ x: '3%', y: '45%' });
            if (!isInitialRender) {
                __Common__.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new CustomPieChart(this, { picChartElements: this.picChartElements2 }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        __Common__.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('收入');
            Text.debugLine("pages/showPage.ets(68:9)");
            Text.height("35vp");
            Text.fontSize('30vp');
            Text.margin({ left: '24vp' });
            Text.position({ x: '45%', y: '75%' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("返回");
            Button.debugLine("pages/showPage.ets(73:9)");
            Button.fontSize(30);
            Button.onClick(() => {
                router.back();
            });
            Button.position({ x: '22%', y: "85%" });
            Button.width("60%");
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ShowPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=showPage.js.map