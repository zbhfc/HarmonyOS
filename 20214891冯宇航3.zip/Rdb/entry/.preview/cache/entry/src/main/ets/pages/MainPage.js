/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import AccountTable from '@bundle:com.example.rdb/entry/ets/common/database/tables/AccountTable';
import CommonConstants from '@bundle:com.example.rdb/entry/ets/common/constants/CommonConstants';
import { DialogComponent } from '@bundle:com.example.rdb/entry/ets/view/DialogComponent';
import { ImageList } from '@bundle:com.example.rdb/entry/ets/viewmodel/AccountList';
import Logger from '@bundle:com.example.rdb/entry/ets/common/utils/Logger';
import DateText from '@bundle:com.example.rdb/entry/ets/view/DateTextComponent';
import CashText from '@bundle:com.example.rdb/entry/ets/view/CashTextComponent';
import { DateFormat } from '@bundle:com.example.rdb/entry/ets/common/utils/Utils';
import { CustomMonthPickerDialog } from '@bundle:com.example.rdb/entry/ets/view/CustomMonthPickerController';
import prompt from '@ohos:promptAction';
import { CustomSearchDialog } from '@bundle:com.example.rdb/entry/ets/view/CustomSearchDialog';
import router from '@ohos:router';
const THEME_NAMES = ['所有账单', '年度账单', '月度账单', '日账单', '测试数据'];
class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__accounts = new ObservedPropertyObjectPU([], this, "accounts");
        this.__scroll_accounts = new ObservedPropertyObjectPU([], this, "scroll_accounts");
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__isEdit = new ObservedPropertySimplePU(false, this, "isEdit");
        this.__isInsert = new ObservedPropertySimplePU(true, this, "isInsert");
        this.__isTested = new ObservedPropertySimplePU(false, this, "isTested");
        this.__yearValue = new ObservedPropertySimplePU('', this, "yearValue");
        this.__monthValue = new ObservedPropertySimplePU('', this, "monthValue");
        this.__searchValue = new ObservedPropertySimplePU('', this, "searchValue");
        this.__submitValue = new ObservedPropertySimplePU('', this, "submitValue");
        this.__cur_search_text = new ObservedPropertySimplePU('', this, "cur_search_text");
        this.__today_incomeValue = new ObservedPropertySimplePU(0, this, "today_incomeValue");
        this.__today_outcomeValue = new ObservedPropertySimplePU(0, this, "today_outcomeValue");
        this.__today_earningValue = new ObservedPropertySimplePU(0, this, "today_earningValue");
        this.__newAccount = new ObservedPropertyObjectPU({
            id: 0,
            accountType: 0,
            typeText: '',
            amount: 0,
            date: '',
            year: '',
            month: '',
            reminder: ''
        }, this, "newAccount");
        this.__index = new ObservedPropertySimplePU(-1, this, "index");
        this.deleteWidth = 100;
        this.downX = 0;
        this.scroll2DeleteData = null;
        this.selected_date = undefined;
        this.select = 8;
        this.years = ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028', '2029', '2030'];
        this.controller = new TextInputController();
        this.AccountTable = new AccountTable(() => {
        });
        this.deleteList = [];
        this.searchController = new SearchController();
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new DialogComponent(this, {
                    isInsert: this.__isInsert,
                    newAccount: this.__newAccount,
                    confirm: (isInsert, newAccount) => this.accept(isInsert, newAccount)
                });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
            },
            customStyle: true,
            alignment: DialogAlignment.Bottom
        }, this);
        this.CustomMonthPickerController = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomMonthPickerDialog(this, {
                    yearValue: this.__yearValue,
                    monthValue: this.__monthValue,
                    searchValue: this.__searchValue,
                    confirm: (yearValue, monthValue, searchValue) => this.customAccept(yearValue, monthValue, searchValue)
                });
                jsDialog.setController(this.CustomMonthPickerController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true,
            alignment: DialogAlignment.Bottom,
            offset: { dx: 0, dy: -10 },
            gridCount: 4,
            customStyle: false
        }, this);
        this.searchDialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomSearchDialog(this, {
                    confirm: (submitValue) => this.customSearchAccept(submitValue),
                    submitValue: this.__submitValue,
                });
                jsDialog.setController(this.searchDialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: true,
            alignment: DialogAlignment.Bottom,
            gridCount: 4,
            customStyle: false
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.accounts !== undefined) {
            this.accounts = params.accounts;
        }
        if (params.scroll_accounts !== undefined) {
            this.scroll_accounts = params.scroll_accounts;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.isEdit !== undefined) {
            this.isEdit = params.isEdit;
        }
        if (params.isInsert !== undefined) {
            this.isInsert = params.isInsert;
        }
        if (params.isTested !== undefined) {
            this.isTested = params.isTested;
        }
        if (params.yearValue !== undefined) {
            this.yearValue = params.yearValue;
        }
        if (params.monthValue !== undefined) {
            this.monthValue = params.monthValue;
        }
        if (params.searchValue !== undefined) {
            this.searchValue = params.searchValue;
        }
        if (params.submitValue !== undefined) {
            this.submitValue = params.submitValue;
        }
        if (params.cur_search_text !== undefined) {
            this.cur_search_text = params.cur_search_text;
        }
        if (params.today_incomeValue !== undefined) {
            this.today_incomeValue = params.today_incomeValue;
        }
        if (params.today_outcomeValue !== undefined) {
            this.today_outcomeValue = params.today_outcomeValue;
        }
        if (params.today_earningValue !== undefined) {
            this.today_earningValue = params.today_earningValue;
        }
        if (params.newAccount !== undefined) {
            this.newAccount = params.newAccount;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.deleteWidth !== undefined) {
            this.deleteWidth = params.deleteWidth;
        }
        if (params.downX !== undefined) {
            this.downX = params.downX;
        }
        if (params.scroll2DeleteData !== undefined) {
            this.scroll2DeleteData = params.scroll2DeleteData;
        }
        if (params.selected_date !== undefined) {
            this.selected_date = params.selected_date;
        }
        if (params.select !== undefined) {
            this.select = params.select;
        }
        if (params.years !== undefined) {
            this.years = params.years;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.AccountTable !== undefined) {
            this.AccountTable = params.AccountTable;
        }
        if (params.deleteList !== undefined) {
            this.deleteList = params.deleteList;
        }
        if (params.searchController !== undefined) {
            this.searchController = params.searchController;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
        if (params.CustomMonthPickerController !== undefined) {
            this.CustomMonthPickerController = params.CustomMonthPickerController;
        }
        if (params.searchDialogController !== undefined) {
            this.searchDialogController = params.searchDialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__accounts.purgeDependencyOnElmtId(rmElmtId);
        this.__scroll_accounts.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__isEdit.purgeDependencyOnElmtId(rmElmtId);
        this.__isInsert.purgeDependencyOnElmtId(rmElmtId);
        this.__isTested.purgeDependencyOnElmtId(rmElmtId);
        this.__yearValue.purgeDependencyOnElmtId(rmElmtId);
        this.__monthValue.purgeDependencyOnElmtId(rmElmtId);
        this.__searchValue.purgeDependencyOnElmtId(rmElmtId);
        this.__submitValue.purgeDependencyOnElmtId(rmElmtId);
        this.__cur_search_text.purgeDependencyOnElmtId(rmElmtId);
        this.__today_incomeValue.purgeDependencyOnElmtId(rmElmtId);
        this.__today_outcomeValue.purgeDependencyOnElmtId(rmElmtId);
        this.__today_earningValue.purgeDependencyOnElmtId(rmElmtId);
        this.__newAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__accounts.aboutToBeDeleted();
        this.__scroll_accounts.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__isEdit.aboutToBeDeleted();
        this.__isInsert.aboutToBeDeleted();
        this.__isTested.aboutToBeDeleted();
        this.__yearValue.aboutToBeDeleted();
        this.__monthValue.aboutToBeDeleted();
        this.__searchValue.aboutToBeDeleted();
        this.__submitValue.aboutToBeDeleted();
        this.__cur_search_text.aboutToBeDeleted();
        this.__today_incomeValue.aboutToBeDeleted();
        this.__today_outcomeValue.aboutToBeDeleted();
        this.__today_earningValue.aboutToBeDeleted();
        this.__newAccount.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get accounts() {
        return this.__accounts.get();
    }
    set accounts(newValue) {
        this.__accounts.set(newValue);
    }
    get scroll_accounts() {
        return this.__scroll_accounts.get();
    }
    set scroll_accounts(newValue) {
        this.__scroll_accounts.set(newValue);
    }
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue) {
        this.__searchText.set(newValue);
    }
    get isEdit() {
        return this.__isEdit.get();
    }
    set isEdit(newValue) {
        this.__isEdit.set(newValue);
    }
    get isInsert() {
        return this.__isInsert.get();
    }
    set isInsert(newValue) {
        this.__isInsert.set(newValue);
    }
    get isTested() {
        return this.__isTested.get();
    }
    set isTested(newValue) {
        this.__isTested.set(newValue);
    }
    get yearValue() {
        return this.__yearValue.get();
    }
    set yearValue(newValue) {
        this.__yearValue.set(newValue);
    }
    get monthValue() {
        return this.__monthValue.get();
    }
    set monthValue(newValue) {
        this.__monthValue.set(newValue);
    }
    get searchValue() {
        return this.__searchValue.get();
    }
    set searchValue(newValue) {
        this.__searchValue.set(newValue);
    }
    get submitValue() {
        return this.__submitValue.get();
    }
    set submitValue(newValue) {
        this.__submitValue.set(newValue);
    }
    get cur_search_text() {
        return this.__cur_search_text.get();
    }
    set cur_search_text(newValue) {
        this.__cur_search_text.set(newValue);
    }
    get today_incomeValue() {
        return this.__today_incomeValue.get();
    }
    set today_incomeValue(newValue) {
        this.__today_incomeValue.set(newValue);
    }
    get today_outcomeValue() {
        return this.__today_outcomeValue.get();
    }
    set today_outcomeValue(newValue) {
        this.__today_outcomeValue.set(newValue);
    }
    get today_earningValue() {
        return this.__today_earningValue.get();
    }
    set today_earningValue(newValue) {
        this.__today_earningValue.set(newValue);
    }
    get newAccount() {
        return this.__newAccount.get();
    }
    set newAccount(newValue) {
        this.__newAccount.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    accept(isInsert, newAccount) {
        if (isInsert) {
            Logger.info(`${CommonConstants.INDEX_TAG}`, `The account inserted is:  ${JSON.stringify(newAccount)}`);
            this.AccountTable.insertData(newAccount, (id) => {
                newAccount.id = id;
                this.accounts.push(newAccount);
                this.scroll_accounts.push({ accountData: newAccount, scroller: new Scroller() });
            });
            if (newAccount != null) {
                if (newAccount.accountType === 0)
                    this.today_outcomeValue += this.newAccount.amount;
                else
                    this.today_incomeValue += this.newAccount.amount;
                this.today_earningValue = this.today_incomeValue - this.today_outcomeValue;
            }
        }
        else {
            this.AccountTable.updateData(newAccount, () => {
            });
            let list = this.accounts;
            this.accounts = [];
            list[this.index] = newAccount;
            this.accounts = list;
            this.index = -1;
        }
    }
    accountData2ScrollData(accounts) {
        this.scroll_accounts = [];
        for (let i = 0; i < accounts.length; ++i) {
            this.scroll_accounts.push({ accountData: accounts[i], scroller: new Scroller() });
        }
    }
    calculate(account) {
        this.today_outcomeValue = 0;
        this.today_incomeValue = 0;
        this.today_earningValue = 0;
        for (let i = 0; i < account.length; ++i) {
            if (account[i].accountType === 0) {
                this.today_outcomeValue += account[i].amount;
            }
            else {
                this.today_incomeValue += account[i].amount;
            }
        }
        this.today_earningValue = this.today_incomeValue - this.today_outcomeValue;
    }
    aboutToAppear() {
        this.AccountTable.getRdbStore(() => {
            this.AccountTable.query('', (result) => {
                this.accounts = result;
                this.initSearchDate();
                this.accountData2ScrollData(this.accounts);
                this.calculate(this.accounts);
                this.cur_search_text = '所有账单';
            }, true);
        });
    }
    initSearchDate() {
        let cur_date = new Date();
        this.cur_search_text = DateFormat(cur_date.getTime());
    }
    selectListItem(item) {
        this.isInsert = false;
        this.index = this.accounts.indexOf(item);
        this.newAccount = {
            id: item.id,
            accountType: item.accountType,
            typeText: item.typeText,
            amount: item.amount,
            date: item.date,
            year: item.year,
            month: item.month,
            reminder: item.reminder
        };
    }
    customSearchAccept(submitValue) {
        if (this.submitValue != '') {
            this.AccountTable.queryType(submitValue, (result) => {
                this.accounts = result;
                this.calculate(this.accounts);
                this.accountData2ScrollData(this.accounts);
            }, false);
            this.cur_search_text = '搜索结果';
        }
    }
    aboutToDisappear() {
        delete this.dialogController;
        this.dialogController = undefined;
    }
    customAccept(yearValue, monthValue, searchValue) {
        if (yearValue == '' || monthValue == '') {
            prompt.showToast({ message: '不能为空', bottom: CommonConstants.PROMPT_BOTTOM });
        }
        else {
            this.cur_search_text = yearValue + '年' + monthValue + '月';
            this.searchValue = searchValue;
            if (this.searchValue != '') {
                this.AccountTable.queryMonth(String(this.searchValue), (result) => {
                    this.accounts = result;
                    this.calculate(this.accounts);
                    this.accountData2ScrollData(this.accounts);
                }, false);
            }
        }
    }
    deleteListItem() {
        for (let i = 0; i < this.deleteList.length; i++) {
            if (this.deleteList[i].accountType === 0)
                this.today_outcomeValue -= this.newAccount.amount;
            else
                this.today_incomeValue -= this.newAccount.amount;
            this.today_earningValue = this.today_incomeValue - this.today_outcomeValue;
            let index = this.accounts.indexOf(this.deleteList[i]);
            this.accounts.splice(index, 1);
            this.AccountTable.deleteData(this.deleteList[i], () => {
            });
        }
        this.deleteList = [];
        this.isEdit = false;
    }
    CustomItem(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Scroll.create(item.scroller);
            Scroll.debugLine("pages/MainPage.ets(223:5)");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.onTouch((event) => {
                if (this.scroll2DeleteData != null && this.scroll2DeleteData != item) {
                    this.scroll2DeleteData.scroller.scrollTo({ xOffset: 0, yOffset: 0,
                        animation: { duration: 100, curve: Curve.Linear } });
                }
                switch (event.type) {
                    case TouchType.Down:
                        this.downX = event.touches[0].x;
                        break;
                    case TouchType.Up:
                        let xOffset = event.touches[0].x - this.downX;
                        if (xOffset == 0) {
                            return;
                        }
                        var toxOffset = 0;
                        this.scroll2DeleteData = null;
                        if (Math.abs(xOffset) > vp2px(this.deleteWidth) / 2 && xOffset < 0) {
                            toxOffset = vp2px(this.deleteWidth);
                            this.scroll2DeleteData = item;
                        }
                        item.scroller.scrollTo({ xOffset: toxOffset, yOffset: 0,
                            animation: { duration: 300, curve: Curve.Linear } });
                        this.downX = 0;
                        break;
                }
            });
            if (!isInitialRender) {
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/MainPage.ets(224:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/MainPage.ets(225:9)");
            Row.width(CommonConstants.FULL_WIDTH);
            Row.padding({ left: '12vp', right: '12vp' });
            Row.onClick(() => {
                if (this.scroll2DeleteData != null) {
                    this.scroll2DeleteData.scroller.scrollTo({ xOffset: 0, yOffset: 0,
                        animation: { duration: 100, curve: Curve.Linear } });
                    this.scroll2DeleteData = null;
                    return;
                }
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(ImageList[item.accountData.typeText]);
            Image.debugLine("pages/MainPage.ets(226:11)");
            Image.width('40vp');
            Image.aspectRatio(CommonConstants.FULL_SIZE);
            Image.margin({ right: '16vp' });
            Image.onClick(() => {
                //this.selectListItem(item.accountData);
                //this.dialogController.open();
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isEdit) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/MainPage.ets(235:13)");
                        Column.alignItems(HorizontalAlign.Start);
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(item.accountData.typeText);
                        Text.debugLine("pages/MainPage.ets(236:15)");
                        Text.height('22vp');
                        Text.fontSize('16vp');
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(item.accountData.date + ' ');
                        Text.debugLine("pages/MainPage.ets(239:15)");
                        Text.fontSize('12vp');
                        Text.fontColor('#FF13A6D0');
                        Text.align(Alignment.Start);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Divider.create();
                        Divider.debugLine("pages/MainPage.ets(247:13)");
                        Divider.vertical(true);
                        Divider.height(22);
                        Divider.color('#FF000000');
                        Divider.opacity(0.6);
                        Divider.margin({ left: 8, right: 8 });
                        if (!isInitialRender) {
                            Divider.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('备注: ' + item.accountData.reminder.toString());
                        Text.debugLine("pages/MainPage.ets(253:13)");
                        Text.fontSize('12vp');
                        Text.fontColor('#FFA6A8AB');
                        Text.align(Alignment.BottomEnd);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Blank.create();
                        Blank.debugLine("pages/MainPage.ets(258:13)");
                        Blank.layoutWeight(1);
                        if (!isInitialRender) {
                            Blank.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Blank.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(item.accountData.accountType === 0 ? '-' + item.accountData.amount.toString() : '+' + item.accountData.amount.toString());
                        Text.debugLine("pages/MainPage.ets(260:13)");
                        Text.fontSize('16vp');
                        Text.fontColor(item.accountData.accountType === 0 ? '#FF6A9F40' : '#FFF54D38');
                        Text.align(Alignment.End);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/MainPage.ets(267:13)");
                        Row.align(Alignment.End);
                        Row.flexGrow(CommonConstants.FULL_SIZE);
                        Row.justifyContent(FlexAlign.End);
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/MainPage.ets(268:15)");
                        Column.alignItems(HorizontalAlign.Start);
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(item.accountData.typeText);
                        Text.debugLine("pages/MainPage.ets(269:17)");
                        Text.height('22vp');
                        Text.fontSize('16vp');
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(item.accountData.date + ' ');
                        Text.debugLine("pages/MainPage.ets(272:17)");
                        Text.fontSize('12vp');
                        Text.fontColor('#FF13A6D0');
                        Text.align(Alignment.Start);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Divider.create();
                        Divider.debugLine("pages/MainPage.ets(280:15)");
                        Divider.vertical(true);
                        Divider.height(22);
                        Divider.color("FF000000");
                        Divider.opacity(0.6);
                        Divider.margin({ left: 8, right: 8 });
                        if (!isInitialRender) {
                            Divider.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('备注: ' + item.accountData.reminder.toString());
                        Text.debugLine("pages/MainPage.ets(286:15)");
                        Text.fontColor('#FFA6A0AB');
                        Text.fontSize('12vp');
                        Text.align(Alignment.BottomEnd);
                        Text.flexGrow(CommonConstants.FULL_SIZE);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Toggle.create({ type: ToggleType.Checkbox });
                        Toggle.debugLine("pages/MainPage.ets(291:15)");
                        Toggle.onChange((isOn) => {
                            if (isOn) {
                                this.deleteList.push(item.accountData);
                            }
                            else {
                                let index = this.deleteList.indexOf(item.accountData);
                                this.deleteList.splice(index, 1);
                            }
                        });
                        if (!isInitialRender) {
                            Toggle.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Toggle.pop();
                    Row.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/MainPage.ets(316:9)");
            Button.type(ButtonType.Normal);
            Button.height(65);
            Button.backgroundColor(Color.Red);
            Button.onClick(() => {
                if (item.accountData.accountType === 0)
                    this.today_outcomeValue -= item.accountData.amount;
                else
                    this.today_incomeValue -= item.accountData.amount;
                this.today_earningValue = this.today_incomeValue - this.today_outcomeValue;
                this.scroll_accounts.splice(this.scroll_accounts.indexOf(item), 1);
                this.accounts.splice(this.accounts.indexOf(item.accountData), 1);
                this.AccountTable.deleteData(item.accountData, () => {
                });
                //this.deleteList.push(item.accountData)
                //this.deleteListItem()
                if (this.scroll2DeleteData != null) {
                    this.scroll2DeleteData.scroller.scrollTo({ xOffset: 0, yOffset: 0,
                        animation: { duration: 100, curve: Curve.Linear } });
                    this.scroll2DeleteData = null;
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('删除');
            Text.debugLine("pages/MainPage.ets(317:11)");
            Text.fontSize(15);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        Row.pop();
        Scroll.pop();
    }
    /*build() {
      Stack() {
        Column() {
          Row() {
            Text('记账本')
              .height($r('app.float.component_size_SP'))
              .fontSize($r('app.float.font_size_L'))
              .margin({ left: $r('app.float.font_size_L') })
  
            Image($rawfile('ic_public_edit.svg'))
              .width($r('app.float.component_size_S'))
              .aspectRatio(CommonConstants.FULL_SIZE)
              .margin({ right: $r('app.float.font_size_L') })
              .onClick(() => {
                this.isEdit = true;
              })
          }
          .width(CommonConstants.FULL_WIDTH)
          .justifyContent(FlexAlign.SpaceBetween)
          .margin({ top: $r('app.float.edge_size_M'), bottom: $r('app.float.edge_size_MM') })
  
          Row() {
            Search({
              value: this.searchText,
              placeholder: CommonConstants.SEARCH_TEXT,
              controller: this.searchController
            })
              .width(CommonConstants.FULL_WIDTH)
              .borderRadius($r('app.float.radius_size_M'))
              .borderWidth($r('app.float.border_size_S'))
              .borderColor($r('app.color.border_color'))
              .placeholderFont({ size: $r('app.float.font_size_M') })
              .textFont({ size: $r('app.float.font_size_M') })
              .backgroundColor(Color.White)
              .onChange((searchValue: string) => {
                this.searchText = searchValue;
              })
              .onSubmit((searchValue: string) => {
                if (searchValue === '') {
                  this.AccountTable.query('', (result: AccountData[]) => {
                    this.accounts = result;
                  }, true);
                } else {
                  this.AccountTable.query('', (result: AccountData[]) => {
                    this.accounts = result;
                  }, false);
                }
              })
          }
          .width(CommonConstants.FULL_WIDTH)
          .padding({ left: $r('app.float.edge_size_M'), right: $r('app.float.edge_size_M') })
          .margin({ top: $r('app.float.edge_size_S'), bottom: $r('app.float.edge_size_S') })
  
          Row() {
            List({ space: CommonConstants.FULL_SIZE }) {
              ForEach(this.accounts, (item: AccountData) => {
                ListItem() {
                  Row() {
                    Image(ImageList[item.typeText])
                      .width($r('app.float.component_size_M'))
                      .aspectRatio(CommonConstants.FULL_SIZE)
                      .margin({ right: $r('app.float.edge_size_MP') })
  
                    Text(item.typeText)
                      .height($r('app.float.component_size_SM'))
                      .fontSize($r('app.float.font_size_M'))
  
                    Blank()
                      .layoutWeight(1)
  
                    if (!this.isEdit) {
                      Text(item.accountType === 0 ? '-' + item.amount.toString() : '+' + item.amount.toString())
                        .fontSize($r('app.float.font_size_M'))
                        .fontColor(item.accountType === 0 ? $r('app.color.pay_color') : $r('app.color.main_color'))
                        .align(Alignment.End)
                        .flexGrow(CommonConstants.FULL_SIZE)
                    } else {
                      Row() {
                        Toggle({ type: ToggleType.Checkbox })
                          .onChange((isOn) => {
                            if (isOn) {
                              this.deleteList.push(item);
                            } else {
                              let index = this.deleteList.indexOf(item);
                              this.deleteList.splice(index, 1);
                            }
                          })
                      }
                      .align(Alignment.End)
                      .flexGrow(CommonConstants.FULL_SIZE)
                      .justifyContent(FlexAlign.End)
                    }
  
                  }
                  .width(CommonConstants.FULL_WIDTH)
                  .padding({ left: $r('app.float.edge_size_M'), right: $r('app.float.edge_size_M') })
                }
                .width(CommonConstants.FULL_WIDTH)
                .height($r('app.float.component_size_LM'))
                .onClick(() => {
                  this.selectListItem(item);
                  this.dialogController.open();
                })
              })
            }
            .width(CommonConstants.FULL_WIDTH)
            .borderRadius($r('app.float.radius_size_L'))
            .backgroundColor(Color.White)
          }
          .width(CommonConstants.FULL_WIDTH)
          .padding({ left: $r('app.float.edge_size_M'), right: $r('app.float.edge_size_M') })
          .margin({ top: $r('app.float.edge_size_SM') })
  
        }
        .width(CommonConstants.FULL_WIDTH)
        .height(CommonConstants.FULL_HEIGHT)
  
        if (!this.isEdit) {
          Button() {
            Image($rawfile('add.png'))
          }
          .width($r('app.float.component_size_MP'))
          .height($r('app.float.component_size_MP'))
          .position({ x: CommonConstants.EDIT_POSITION_X, y: CommonConstants.EDIT_POSITION_Y })
          .onClick(() => {
            this.isInsert = true;
            this.newAccount = { id: 0, accountType: 0, typeText: '', amount: 0, date:'2023年11月10日' , year:'',month:'',reminder:'' };
            this.dialogController.open();
          })
        }
  
        if (this.isEdit) {
          Button() {
            Image($rawfile('delete.png'))
          }
          .width($r('app.float.component_size_MP'))
          .height($r('app.float.component_size_MP'))
          .backgroundColor($r('app.color.background_color'))
          .markAnchor({ x: $r('app.float.mark_anchor'), y: CommonConstants.MINIMUM_SIZE })
          .position({ x: CommonConstants.DELETE_POSITION_X, y: CommonConstants.DELETE_POSITION_Y })
          .onClick(() => {
            this.deleteListItem();
          })
        }
      }
      .width(CommonConstants.FULL_WIDTH)
      .height(CommonConstants.FULL_HEIGHT)
      .backgroundColor($r('app.color.background_color'))
    }
  }*/
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MainPage.ets(533:5)");
            Column.width(CommonConstants.FULL_WIDTH);
            Column.height(CommonConstants.FULL_HEIGHT);
            Column.backgroundColor('#FFE8E7F1');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: CommonConstants.FULL_SIZE, initialIndex: 0 });
            List.debugLine("pages/MainPage.ets(534:7)");
            List.borderRadius('24vp');
            List.backgroundColor(Color.White);
            List.width(CommonConstants.FULL_WIDTH);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/MainPage.ets(535:9)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(536:11)");
                    Row.width(CommonConstants.FULL_WIDTH);
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    Row.margin({ top: '12vp', bottom: '11vp' });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('记账本');
                    Text.debugLine("pages/MainPage.ets(537:13)");
                    Text.height("33vp");
                    Text.fontSize('24vp');
                    Text.margin({ left: '24vp' });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Row.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(536:11)");
                    Row.width(CommonConstants.FULL_WIDTH);
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    Row.margin({ top: '12vp', bottom: '11vp' });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('记账本');
                    Text.debugLine("pages/MainPage.ets(537:13)");
                    Text.height("33vp");
                    Text.fontSize('24vp');
                    Text.margin({ left: '24vp' });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Row.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/MainPage.ets(546:9)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(547:11)");
                    Row.width(CommonConstants.FULL_WIDTH);
                    Row.padding({ left: { "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" }, right: { "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" } });
                    Row.margin({ top: { "id": 16777236, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" }, bottom: { "id": 16777236, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" } });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new DateText(this, {
                                title: this.cur_search_text,
                                fontSize: { "id": 16777239, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi-Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                title: this.cur_search_text
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                Row.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(547:11)");
                    Row.width(CommonConstants.FULL_WIDTH);
                    Row.padding({ left: { "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" }, right: { "id": 16777232, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" } });
                    Row.margin({ top: { "id": 16777236, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" }, bottom: { "id": 16777236, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" } });
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new DateText(this, {
                                title: this.cur_search_text,
                                fontSize: { "id": 16777239, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi-Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                title: this.cur_search_text
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                Row.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/MainPage.ets(559:9)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/MainPage.ets(560:11)");
                    Column.width('100%');
                    Column.height('25%');
                    Column.backgroundImage({ "id": 0, "type": 30000, params: ['111.png'], "bundleName": "com.example.rdb", "moduleName": "entry" }, ImageRepeat.NoRepeat);
                    Column.backgroundImageSize(ImageSize.Cover);
                    Column.alignItems(HorizontalAlign.Start);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '结余: ' + this.today_earningValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '结余: ' + this.today_earningValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(567:13)");
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '收入: ' + this.today_incomeValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '收入: ' + this.today_incomeValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '支出: ' + this.today_outcomeValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '支出: ' + this.today_outcomeValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                Row.pop();
                Column.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/MainPage.ets(560:11)");
                    Column.width('100%');
                    Column.height('25%');
                    Column.backgroundImage({ "id": 0, "type": 30000, params: ['111.png'], "bundleName": "com.example.rdb", "moduleName": "entry" }, ImageRepeat.NoRepeat);
                    Column.backgroundImageSize(ImageSize.Cover);
                    Column.alignItems(HorizontalAlign.Start);
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '结余: ' + this.today_earningValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '结余: ' + this.today_earningValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/MainPage.ets(567:13)");
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '收入: ' + this.today_incomeValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '收入: ' + this.today_incomeValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new CashText(this, {
                                amount: '支出: ' + this.today_outcomeValue.toString(),
                                fontSize: { "id": 16777238, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" },
                                fontFamily: 'HarmonyHeiTi_Bold',
                                fontWeight: 500
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                amount: '支出: ' + this.today_outcomeValue.toString()
                            });
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                Row.pop();
                Column.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.width(CommonConstants.FULL_WIDTH);
                        ListItem.height('56vp');
                        ListItem.debugLine("pages/MainPage.ets(589:11)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.CustomItem.bind(this)(item);
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.CustomItem.bind(this)(item);
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.scroll_accounts, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isEdit) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild();
                        Button.debugLine("pages/MainPage.ets(600:9)");
                        Button.width({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.height({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.position({ x: CommonConstants.EDIT_POSITION_X, y: CommonConstants.EDIT_POSITION_Y });
                        Button.onClick(() => {
                            this.isInsert = true;
                            this.newAccount = { id: 0, accountType: 0, typeText: '', amount: 0, date: '2023年11月10日', year: '2023', month: '2023-11', reminder: '' };
                            this.dialogController.open();
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['add.png'], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Image.debugLine("pages/MainPage.ets(601:11)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild();
                        Button.debugLine("pages/MainPage.ets(611:9)");
                        Button.width({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.height({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.position({ x: '60%', y: CommonConstants.EDIT_POSITION_Y });
                        Button.bindMenu([
                            {
                                value: THEME_NAMES[0],
                                action: () => {
                                    this.cur_search_text = '所有账单';
                                    this.AccountTable.query('', (result) => {
                                        this.accounts = result;
                                        this.accountData2ScrollData(ObservedObject.GetRawObject(this.accounts));
                                        this.calculate(ObservedObject.GetRawObject(this.accounts));
                                    }, true);
                                    this.index = -1;
                                }
                            },
                            {
                                value: THEME_NAMES[1],
                                action: () => {
                                    TextPickerDialog.show({
                                        range: this.years,
                                        selected: this.select,
                                        onAccept: (year_text) => {
                                            this.select = year_text.index;
                                            this.cur_search_text = year_text.value + '年';
                                            this.AccountTable.queryYear(String(year_text.value), (result) => {
                                                this.accounts = result;
                                                this.calculate((this.accounts));
                                                this.accountData2ScrollData(ObservedObject.GetRawObject(this.accounts));
                                            }, false);
                                        }
                                    });
                                }
                            },
                            {
                                value: THEME_NAMES[2],
                                action: () => {
                                    if (this.CustomMonthPickerController != undefined) {
                                        this.CustomMonthPickerController.open();
                                    }
                                }
                            },
                            {
                                value: THEME_NAMES[3],
                                action: () => {
                                    DatePickerDialog.show({
                                        start: new Date('2015-1-1'),
                                        end: new Date('2100-12-31'),
                                        selected: this.selected_date,
                                        onAccept: (value) => {
                                            this.newAccount.date = value.year.toString() + '年'
                                                + (value.month + 1).toString() + '月'
                                                + value.day.toString() + '日';
                                            this.newAccount.year = value.year.toString();
                                            this.newAccount.month = value.month.toString();
                                            this.cur_search_text = value.year.toString() + '年' + (value.month + 1).toString() + '月'
                                                + value.day.toString() + '日';
                                            this.AccountTable.query(String(this.newAccount.date), (result) => {
                                                this.accounts = result;
                                                this.accountData2ScrollData(ObservedObject.GetRawObject(this.accounts));
                                                this.calculate(ObservedObject.GetRawObject(this.accounts));
                                            }, false);
                                        }
                                    });
                                }
                            }
                        ]);
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['search.png'], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Image.debugLine("pages/MainPage.ets(612:11)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild();
                        Button.debugLine("pages/MainPage.ets(681:9)");
                        Button.width({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.height({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.position({ x: '40%', y: CommonConstants.EDIT_POSITION_Y });
                        Button.onClick(() => {
                            this.searchDialogController.open();
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['find.png'], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Image.debugLine("pages/MainPage.ets(682:11)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild();
                        Button.debugLine("pages/MainPage.ets(690:9)");
                        Button.width({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.height({ "id": 16777225, "type": 10002, params: [], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Button.position({ x: '20%', y: CommonConstants.EDIT_POSITION_Y });
                        Button.onClick(() => {
                            router.pushUrl({
                                url: 'pages/showPage',
                                params: {
                                    data: this.accounts,
                                    title: this.cur_search_text
                                }
                            }, router.RouterMode.Standard);
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 0, "type": 30000, params: ['show.png'], "bundleName": "com.example.rdb", "moduleName": "entry" });
                        Image.debugLine("pages/MainPage.ets(691:11)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MainPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MainPage.js.map