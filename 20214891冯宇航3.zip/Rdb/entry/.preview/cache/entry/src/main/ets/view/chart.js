export class CustomPieChart extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.picChartElements = undefined;
        this.__circle_radius = new ObservedPropertySimplePU(80
        // 单位
        , this, "circle_radius");
        this.__unit = new ObservedPropertySimplePU("元"
        // 获取上下文
        , this, "unit");
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.picChartElements !== undefined) {
            this.picChartElements = params.picChartElements;
        }
        if (params.circle_radius !== undefined) {
            this.circle_radius = params.circle_radius;
        }
        if (params.unit !== undefined) {
            this.unit = params.unit;
        }
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__circle_radius.purgeDependencyOnElmtId(rmElmtId);
        this.__unit.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__circle_radius.aboutToBeDeleted();
        this.__unit.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get circle_radius() {
        return this.__circle_radius.get();
    }
    set circle_radius(newValue) {
        this.__circle_radius.set(newValue);
    }
    get unit() {
        return this.__unit.get();
    }
    set unit(newValue) {
        this.__unit.set(newValue);
    }
    aboutToAppear() {
        let total = 0;
        // 统计总数量
        this.picChartElements.forEach((value) => {
            total += value.quantity;
        });
        // 初始化 弧线的终止弧度
        let lastEndAngle = -0.5 * Math.PI;
        // 封装饼图数据
        this.picChartElements.forEach((value) => {
            // 占用百分比
            let percent = value.quantity / total;
            // 四舍五入，获取整数
            value.percent = Math.round(percent * 100);
            // 初始化终止弧度为 弧线的起始弧度
            value.beginAngle = lastEndAngle;
            // 计算弧线的终止弧度
            value.endAngle = (percent * 2 * Math.PI) + lastEndAngle;
            // 赋值终止弧度为变量，作为下次的起始弧度
            lastEndAngle = value.endAngle;
            // 返回封装好的对象
            return value;
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 30 });
            Column.debugLine("view/chart.ets(40:5)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Canvas.create(this.context);
            Canvas.debugLine("view/chart.ets(41:7)");
            Canvas.height(this.circle_radius * 2);
            Canvas.aspectRatio(1);
            Canvas.onReady(() => {
                this.picChartElements.forEach((item) => {
                    // 创建一个新的控制路径
                    this.context.beginPath();
                    // 路径从当前点移动到指定点
                    this.context.moveTo(this.circle_radius, this.circle_radius);
                    // 绘制弧线路径(弧线圆心的x坐标值,弧线圆心的y坐标值,弧线的圆半径,弧线的起始弧度,弧线的终止弧度)
                    this.context.arc(this.circle_radius, this.circle_radius, this.circle_radius, item.beginAngle, item.endAngle);
                    // 指定绘制的填充色
                    this.context.fillStyle = item.color;
                    // 对封闭路径进行填充
                    this.context.fill();
                });
            });
            if (!isInitialRender) {
                Canvas.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Canvas.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Flex.create({ direction: FlexDirection.Row, wrap: FlexWrap.Wrap, justifyContent: FlexAlign.SpaceAround });
            Flex.debugLine("view/chart.ets(61:7)");
            Flex.width('100%');
            if (!isInitialRender) {
                Flex.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create({ space: 4 });
                    Row.debugLine("view/chart.ets(63:11)");
                    Row.height(30);
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 标注圆点颜色
                    Circle.create({ width: 8, height: 8 });
                    Circle.debugLine("view/chart.ets(65:13)");
                    // 标注圆点颜色
                    Circle.fill(item.color);
                    if (!isInitialRender) {
                        // 标注圆点颜色
                        Circle.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 标注文本
                    Text.create(item.element);
                    Text.debugLine("view/chart.ets(67:13)");
                    // 标注文本
                    Text.fontSize(12);
                    if (!isInitialRender) {
                        // 标注文本
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                // 标注文本
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    // 标注数量
                    Text.create(item.quantity + ' ' + this.unit);
                    Text.debugLine("view/chart.ets(69:13)");
                    // 标注数量
                    Text.fontSize(12);
                    if (!isInitialRender) {
                        // 标注数量
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                // 标注数量
                Text.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.picChartElements, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Flex.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class PicChartElement {
    constructor(element, quantity, color) {
        this.element = element;
        this.quantity = quantity;
        this.color = color;
    }
}
//# sourceMappingURL=chart.js.map